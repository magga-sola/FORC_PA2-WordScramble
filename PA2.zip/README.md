# PA2-WordScramble


in order to compile and run the program:
>g++ -o XXX word_jumble.cpp
> ./XXX
